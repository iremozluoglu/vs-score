def test_import():
    import vs_score 